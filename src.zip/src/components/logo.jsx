export default function Logo() {
  return (
    <div className="logo">
      video<span style={{ color: "#f44336" }}>belajar</span>
    </div>
  );
}
